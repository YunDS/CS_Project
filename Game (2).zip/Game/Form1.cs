﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            AssignIconsToSquares(); //Form1 시작할때 랜덤 아이콘 배치 메소드 호출
        }

        Random random = new Random();

        //문자
        List<string> icons = new List<string>() //아이콘 생성
        {
            "%", "%", "j", "j", "p", "p", "k", "k",
            "b", "b", "f", "f", "S", "S", "u", "u"
        };

        private void AssignIconsToSquares() //레이블에 랜덤 아이콘 배치
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {//foreach - 같은 작업을 여러번 수행하려는 경우 사용
                Label iconLabel = control as Label; //control 변수를 iconLael 레이블로 변환
                if (iconLabel != null)
                {
                    int randomNumber = random.Next(icons.Count); //randomNumber 변수 생성 및 랜덤 아이콘 수만큼 초기화
                    iconLabel.Text = icons[randomNumber]; //iconLabel.Text에 icons[난수] 삽입
                    icons.RemoveAt(randomNumber); //Label에 추가한 아이콘 목록에서 제거
                }
            }
        }

        private void label1_Click(object sender, EventArgs e) //레이블 눌렀을때 이벤트 처리
        {
            Label clickedLabel = sender as Label;

            if (clickedLabel != null) //레이블 컨트롤로 변환 되었는지 여부 확인
            {
                if (clickedLabel.ForeColor == Color.Black) //레이블의 텍스트 색상 검정이면
                    return; //이미 선택됨으로 메소드 완료

                if (firstClicked == null) //firstClicked 가 Null상태일때
                {
                    firstClicked = clickedLabel; // 클릭하면 
                    firstClicked.ForeColor = Color.Black; //텍스트를 검정으로 바꾼다
                    return;
                }

                secondClicked = clickedLabel; //두번째 레이블 클릭
                secondClicked.ForeColor = Color.Black; // 텍스트 검정으로 바꿈

                CheckForWinner();

                if (firstClicked.Text == secondClicked.Text) //첫번째 레이블과 두번째 레이블이 같으면
                {
                    firstClicked = null; //첫번째, 두번째 레이블 null
                    secondClicked = null; 
                    return; //새 if문 실행되고 return은 메소드가 타이머를 시작하는 코드를 건너뛰게 하여
                    //다음 이미지와 아이콘이 계속 표시 됨.
                }

                timer1.Start(); //클릭시 타이머 시작
            }
        }
        Label firstClicked = null; //플레이어의 첫번째 클릭 레이블
        Label secondClicked = null; //플레이어의 두번째 클릭 레이블

        private void timer1_Tick(object sender, EventArgs e) //Tick 이벤트 처리기
        {
            timer1.Stop(); //timer 종료

            firstClicked.ForeColor = firstClicked.BackColor;    //텍스트 색상을 배경색과 동일
            secondClicked.ForeColor = secondClicked.BackColor;

            firstClicked = null; //레이블 null
            secondClicked = null;
        }

        private void CheckForWinner() // 게임 완료시
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label;

                if (iconLabel != null)
                {
                    if (iconLabel.ForeColor == iconLabel.BackColor) //아직 맞추지 않은게 존재시
                        return; //종료 하지 않음
                }
            }

            MessageBox.Show("모든 짝을 맞추셨군요~ \n축하드립니다~", "Congratulations"); //메시지 박스 출력
            Close();
        }

        private void x6SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tableLayoutPanel1.ColumnCount = 6;
            tableLayoutPanel1.RowCount = 6;
            tableLayoutPanel1.Width = 644;
            tableLayoutPanel1.Height = 644;
            for (int i = 0; i < 6; i++)
            {
                tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25));
                tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25));
            }
        }

        private void 새게임NToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void x4FToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.Width = 430;
            tableLayoutPanel1.Height = 430;
        }
    }
}
